also install one of these: https://www.lfd.uci.edu/~gohlke/pythonlibs/#videocapture


