import sys
from .base import main

def script_main():
    sys.exit(main(sys.argv))