__version__ = '0.4.0'
__author__ = 'Gaming32'

__all__ = ['__version__', '__author__']