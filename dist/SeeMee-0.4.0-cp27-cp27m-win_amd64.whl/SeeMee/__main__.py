from . import script_main
script_main()